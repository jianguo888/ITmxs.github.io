package com.raywenderlich.rayworld

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
